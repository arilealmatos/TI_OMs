package Ocsinventory::Agent::Backend::Virtualization::Xen;

$runMeIfTheseChecksFailed = ["Ocsinventory::Agent::Backend::Virtualization::Libvirt"];

1;
