# Random Password Generator - HTML | CSS | JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/OJBQLZK](https://codepen.io/Codewithshobhit/pen/OJBQLZK).

Hey guys, I think it's been a long time since I posted any code in Codepen. Sorry I was busy with School works. But I am happy I got back.

Design : https://dribbble.com/shots/5900275-Password-Manager-App-Generate-Password-Settings