# Responsive Navbar With Search & Login
## [Watch it on youtube](https://youtu.be/kviVE1t06Rg)
### Responsive Navbar With Search & Login

- Responsive Navbar Using HTML CSS & JavaScript
- It contains a search box & a login form
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
